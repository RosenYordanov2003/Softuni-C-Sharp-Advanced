﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace IteratorsAndComparators
{
    internal class Program
    {
        public static void Main()
        {
            Book bookOne = new Book("Animal Farm", 2003, "George Orwell");
            Book bookTwo = new Book("The Documents in the Case", 2002, "Dorothy Sayers", "Robert Eustace");
            Book bookThree = new Book("The Documents in the Case", 1930);

            Library library = new Library(bookOne, bookTwo, bookThree);
            foreach (Book book in library)
            {
                Console.WriteLine(book);
            }
            //Car car1 = new Car("BMW", 500);
            //Car car2 = new Car("Mercedes", 100);
            //Car car3 = new Car("Audi", 470);
            // SortedSet<Car> cars = new SortedSet<Car>(new CarComparer()) { car1, car2, car3 };
            //foreach (Car car in cars)
            //{
            //    Console.WriteLine($"{car.Model}: {car.HorsePower}");
            //}
        }

    }
    //public class Car
    //{
    //    public Car(string model, int horsePower)
    //    {
    //        Model = model;
    //        HorsePower = horsePower;
    //    }

    //    public string Model { get; set; }
    //    public int HorsePower { get; set; }
    //}
    //public class CarComparer : IComparer<Car>
    //{
    //    public int Compare([AllowNull] Car first, [AllowNull] Car second)
    //    {
    //        return second.HorsePower.CompareTo(first.HorsePower);
    //    }
    //}
}
