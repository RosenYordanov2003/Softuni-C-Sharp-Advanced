﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Special_Cars
{
    internal class Engine
    {
    }
}
