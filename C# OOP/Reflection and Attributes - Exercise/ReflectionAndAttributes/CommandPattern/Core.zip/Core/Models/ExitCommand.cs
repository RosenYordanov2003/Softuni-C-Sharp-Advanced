﻿using CommandPattern.Core.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace CommandPattern.Core.Models
{
    public class ExitCommand : ICommand
    {
        private const int SUCCESS_EXIT_CODE = 0;
        public string Execute(string[] args)
        {
           Environment.Exit(SUCCESS_EXIT_CODE);
            return null;
        }
    }
}
