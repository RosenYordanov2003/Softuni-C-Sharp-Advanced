﻿namespace Vehicles.ExceptionMessages
{
    public static class ExceptionMessages
    {
        public const string INVALID_FUEAL_AMOUNT = "Cannot fit {0} fuel in the tank";
        public const string NEGATIVE_FUEL = "Fuel must be a positive number";
    }
}
