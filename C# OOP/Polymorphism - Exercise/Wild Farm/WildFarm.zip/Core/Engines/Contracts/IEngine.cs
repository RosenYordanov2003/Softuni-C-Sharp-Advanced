﻿namespace Wild_Farm.Core.Engines.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
