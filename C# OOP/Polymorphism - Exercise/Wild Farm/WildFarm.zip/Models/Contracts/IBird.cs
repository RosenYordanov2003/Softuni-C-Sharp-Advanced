﻿namespace Wild_Farm.Models.Contracts
{
    public interface IBird : IAnimal
    {
        public double WingSize { get;}
    }
}
