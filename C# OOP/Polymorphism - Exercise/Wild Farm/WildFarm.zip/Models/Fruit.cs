﻿namespace Wild_Farm.Models
{
    public class Fruit : Food
    {
        public Fruit(int quantity) : base(quantity)
        {
        }
    }
}
