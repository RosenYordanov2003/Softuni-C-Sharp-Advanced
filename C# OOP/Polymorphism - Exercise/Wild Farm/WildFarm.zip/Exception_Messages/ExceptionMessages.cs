﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wild_Farm.Exception_Messages
{
    public static class ExceptionMessages
    {
        public const string INVALID_FOOD = "{0} does not eat {1}!";
    }
}
