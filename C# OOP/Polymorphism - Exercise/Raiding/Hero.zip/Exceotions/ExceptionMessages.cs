﻿namespace Raiding.Exceotions
{
    public static class ExceptionMessages
    {
        public const string INVALID_HERO_TYPE = "Invalid hero!";
    }
}
