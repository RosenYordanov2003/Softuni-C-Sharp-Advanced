﻿namespace Raiding
{
    public interface IEngine
    {
        void Run();
    }
}
