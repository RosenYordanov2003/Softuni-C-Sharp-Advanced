﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    interface IBrowsable
    {
        string Browse(string urlAddressName);
    }
}
