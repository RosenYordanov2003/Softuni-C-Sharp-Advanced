﻿using Military_Elite.Enums;


namespace Military_Elite.Contracts
{
    public interface ISpecialSoldier:IPrivate
    {
        public Corps Corp { get;}
    }
}
