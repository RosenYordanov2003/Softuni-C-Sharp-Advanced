﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Collection_Hierarchy.Contracts
{
    public interface IAddCollection
    {
        int Add(string item);
    }
}
