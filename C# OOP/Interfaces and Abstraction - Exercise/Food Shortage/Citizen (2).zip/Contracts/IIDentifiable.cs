﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Food_Shortage
{
    public interface IIDentifiable
    {
        public string Id { get; set; }
    }
}
