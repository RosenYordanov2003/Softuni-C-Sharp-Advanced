﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Birthday_Celebrations
{
    public interface IIDentifiable
    {
        public string Id { get; set; }
    }
}
