﻿using System;

namespace Shapes
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Shape shape = null;
            string shapeType = Console.ReadLine();
            if (shapeType=="Circle")
            {
                shape = new Circle(2.5);
                Console.WriteLine(shape.Draw());
            }
        }
    }
}
