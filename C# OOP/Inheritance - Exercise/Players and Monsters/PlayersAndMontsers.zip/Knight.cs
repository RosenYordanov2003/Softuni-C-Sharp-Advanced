﻿using PlayersAndMonsters;
using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    public class Knight:Hero
    {
        public Knight(string userName, int level):base(userName, level)
        {

        }
    }
}
